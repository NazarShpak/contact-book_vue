<template>
  <div id="app">
<!--    <about-contact-page></about-contact-page>-->
    <router-view></router-view>
  </div>
</template>

<script>
// import AllContactsPage from './pages/AllContactsPage.vue'
// import AboutContactPage from './pages/AboutContactPage.vue'

export default {
  name: 'App',
  components: {
    // AllContactsPage
    // AboutContactPage
  }
}
</script>

<style>
</style>
